package org.example;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;

@WebServlet("/support")
public class SupportServlet extends HttpServlet{
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        PrintWriter out = resp.getWriter();
        /*out.print("<html><head><title>Support</title></head><body>");
        out.print("<form method='post'>");
        out.print("<p>Please click the button</p>");
        out.print("<input type='submit' value='Click me'/>");
        out.print("</form>");
        out.print("</body></html>");*/
        out.print("<html><head><title>Support</title></head><body>");
        out.print("<form method='POST'>");
        out.print("<fieldset>");
        out.print("<legend>Ticket</legend>");
        out.print("<label>Name: <input type='text' name='name' required /></label></br>");
        out.println("<label>Email: <input type='email' name='email' required /></label></br>");
        out.println("<label>Problem: <input type='text' name='problem'></label></br>");
        out.println("<label>Description:</label></br> <textarea name='desc' cols='30' rows='10'></textarea></br>");
        out.println("<input type='submit' value='Help' />");
        out.print("</fieldset></form></body></html>");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        ServletContext sc = this.getServletContext();
        Random id = new Random();
        String name = req.getParameter("name");
        String email = req.getParameter("email");
        String problem = req.getParameter("problem");
        String desc = req.getParameter("desc");

        PrintWriter out = resp.getWriter();
        String str = "Thank you! "+name+" for contacting us. We should receive reply from us with in 24 hrs in your email address ["+email+"]. Let us know in our support email ["+sc.getInitParameter("support_email")+"] if you don&apos;t receive reply within 24 hrs." +
                "<br> Your Ticket ID:"+id.nextInt(14);
        out.print("<html><head><title>Test</title></head><body>");
        out.print("<p>"+str+"</p>");
        out.print("</body></html>");
    }
}

package controller;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet({"/login", ""})
public class LoginServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("login.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String userName = req.getParameter("userName");
        String password = req.getParameter("password");
        String remember = req.getParameter("remember");

        HttpSession session = req.getSession();

        if(userName.equals("Badis") && password.equals("badis")){
            session.setAttribute("user", userName);

            if ("yes".equals(remember)){
                Cookie c = new Cookie("user", userName);
                c.setMaxAge(30*24*60*60);
                resp.addCookie(c);
            } else {
                Cookie c = new Cookie("user", null);
                c.setMaxAge(0);
                resp.addCookie(c);
            }
            resp.sendRedirect("welcome.jsp");
        }else{
            session.setAttribute("errMsg", "Username or password is invalid!");
            resp.sendRedirect("login");
        }
    }
}
